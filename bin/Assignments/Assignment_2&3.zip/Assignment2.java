//Assignment 2 :
package Assignments;

public class Assignment2 {

    public static void main(String[] args) {
    	short age = 18 ;
    	char character = 'A';
    	boolean isLike = true;

		System.out.println("My Age is: "+age);
		System.out.println("My favourite character is: "+character);
		System.out.println("I like Java: " +isLike);
    }

}