//Assignment 3 :
package Assignments;

public class Calculator {
	
    public static void main(String[] args) {
    	int val1;
    	int val2;
    	
    	val1 = 10;
    	val2 = 20;
		System.out.println("plus is : "+ (val1 + val2));
		System.out.println("subtract is: "+ (val1 - val2));
		System.out.println("multiply is: "+ val1 * val2);
		System.out.println("devision is: "+ val2 / val1);
		System.out.println("module is: "+ val2 % val1);
    }
}
